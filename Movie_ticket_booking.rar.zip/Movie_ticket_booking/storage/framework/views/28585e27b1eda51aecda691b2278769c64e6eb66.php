<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Karma", sans-serif}
.w3-bar-block .w3-bar-item {padding:20px}

/* green */
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

/* red */
.button2 {background-color: #f44336;}

/* blue */
.button3 {background-color: #008CBA;}

.center {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
<?php /**PATH G:\xampp\htdocs\laravel projects\Movie_ticket_booking\resources\views/style.blade.php ENDPATH**/ ?>