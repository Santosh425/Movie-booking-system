<!DOCTYPE html>
<html>
<title>Seat Book</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">

<?php echo $__env->make('style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

  <!-- Sidebar (hidden by default) -->
  <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Top menu -->
  <?php echo $__env->make('topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- !Page  CONTENT! -->
  <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <form action="<?php echo e(route('book_seat',['movie_id'=>$mt->movie_id, 'movie_time'=>$mt->m_time_id])); ?>" method="get">

    <div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:100px">

      <!-- Silver seat -->
      <?php if(!empty($booked_silver)): ?>
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Silver</h3>
        <?php
        $j=0;
        ?>

        <?php for($i=0; $i<count($seats_silver); $i++ ): ?>
        <?php if($seats_silver[$i]->seat_id == $booked_silver[$j]->seat_id): ?>
        <div class="w3-quarter">
          <button class="button button2">|__|</button>
          <p><?php echo e($seats_silver[$i]->seat); ?></p>

        </div>
        <?php if(count($booked_silver)-1 != $j): ?>
        <?php
        $j++;
        ?>
        <?php endif; ?>

        <?php else: ?>
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p><?php echo e($seats_silver[$i]->seat); ?></p>
          <input type="checkbox" name="seat_id[]" value="<?php echo e($seats_silver[$i]->seat_id); ?>">
        </div>

        <?php endif; ?>

        <?php endfor; ?>
      </div>

      <?php else: ?>
      <!-- silver seat not booked any  -->
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Silver</h3>
        <?php $__currentLoopData = $seats_silver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p><?php echo e($seats->seat); ?></p>
          <input type="checkbox" name="seat_id[]" value="<?php echo e($seats->seat_id); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>


      <hr>

      <!-- gold seats  -->

      <?php if(!empty($booked_gold)): ?>
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Gold</h3>
        <?php
        $j=0;
        ?>

        <?php for($i=0; $i<count($seats_gold); $i++ ): ?>
        <?php if($seats_gold[$i]->seat_id == $booked_gold[$j]->seat_id): ?>
        <div class="w3-quarter">
          <button class="button button2">|__|</button>
          <p><?php echo e($seats_gold[$i]->seat); ?></p>

        </div>
        <?php if(count($booked_gold)-1 != $j): ?>
        <?php
        $j++;
        ?>
        <?php endif; ?>

        <?php else: ?>
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p><?php echo e($seats_gold[$i]->seat); ?></p>
          <input type="checkbox" name="seat_id[]" value="<?php echo e($seats_gold[$i]->seat_id); ?>">
        </div>

        <?php endif; ?>

        <?php endfor; ?>
      </div>

      <?php else: ?>
      <!-- gold seat not booked any  -->
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Gold</h3>
        <?php $__currentLoopData = $seats_gold; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p><?php echo e($seats->seat); ?></p>
          <input type="checkbox" name="seat_id[]" value="<?php echo e($seats->seat_id); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>


      <hr>


      <!-- Platinum seats  -->

      <?php if(!empty($booked_platinum)): ?>
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Platinum</h3>
        <?php
        $j=0;
        ?>

        <?php for($i=0; $i<count($seats_platinum); $i++ ): ?>
        <?php if($seats_platinum[$i]->seat_id == $booked_platinum[$j]->seat_id): ?>
        <div class="w3-quarter">
          <button class="button button2">|__|</button>
          <p><?php echo e($seats_platinum[$i]->seat); ?></p>
          <p>B</p>
        </div>
        <?php if(count($booked_platinum)-1 != $j): ?>
        <?php
        $j++;
        ?>
        <?php endif; ?>

        <?php else: ?>
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p><?php echo e($seats_platinum[$i]->seat); ?></p>
          <input type="checkbox" name="seat_id[]" value="<?php echo e($seats_platinum[$i]->seat_id); ?>">
        </div>

        <?php endif; ?>

        <?php endfor; ?>
      </div>

      <?php else: ?>
      <!-- Platinum seat not booked any  -->
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Platinum</h3>
        <?php $__currentLoopData = $seats_platinum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p><?php echo e($seats->seat); ?></p>
          <input type="checkbox" name="seat_id[]" value="<?php echo e($seats->seat_id); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>

      <hr>
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <div class="w3-quarter">
          <button class="button button3" type="submit">BOOK</button>
        </div>
      </div>
      <h3 class="center">__\_____SCREEN______/__</h3>
      <!-- End page content -->
    </div>

  </form>

</body>
</html>
<?php /**PATH G:\xampp\htdocs\laravel projects\Movie_ticket_booking\resources\views/movie_seat.blade.php ENDPATH**/ ?>