<nav class="w3-sidebar w3-bar-block w3-card w3-top w3-xlarge w3-animate-left" style="display:none;z-index:2;width:40%;min-width:300px" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()"
  class="w3-bar-item w3-button"><</a>
  <a href="<?php echo e(route('welcome')); ?>" onclick="w3_close()" class="w3-bar-item w3-button">Home</a>
  <a href="<?php echo e(route('bookings')); ?>" onclick="w3_close()" class="w3-bar-item w3-button">My Bookings</a>


</nav>


<script>
// Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>
<?php /**PATH G:\xampp\htdocs\laravel projects\Movie_ticket_booking\resources\views/sidebar.blade.php ENDPATH**/ ?>