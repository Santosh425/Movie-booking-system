
<div class="w3-top">
  <div class="w3-white w3-xlarge" style="max-width:1200px;margin:auto">
    <div class="w3-button w3-padding-16 w3-left" onclick="w3_open()">☰</div>
    <div class="w3-right w3-padding-16">IMMO</div>
    <div class="w3-center w3-padding-16">Movie Ticket booking </div>
  </div>
</div>
