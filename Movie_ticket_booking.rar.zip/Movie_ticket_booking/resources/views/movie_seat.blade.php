<!DOCTYPE html>
<html>
<title>Seat Book</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">

@include('style')

<body>

  <!-- Sidebar (hidden by default) -->
  @include('sidebar')

  <!-- Top menu -->
  @include('topnav')

  <!-- !Page  CONTENT! -->
  @foreach($movie as $mt)
  @endforeach
  <form action="{{route('book_seat',['movie_id'=>$mt->movie_id, 'movie_time'=>$mt->m_time_id])}}" method="get">

    <div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:100px">

      <!-- Silver seat -->
      @if(!empty($booked_silver))
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Silver</h3>
        @php
        $j=0;
        @endphp

        @for($i=0; $i<count($seats_silver); $i++ )
        @if($seats_silver[$i]->seat_id == $booked_silver[$j]->seat_id)
        <div class="w3-quarter">
          <button class="button button2">|__|</button>
          <p>{{ $seats_silver[$i]->seat}}</p>

        </div>
        @if(count($booked_silver)-1 != $j)
        @php
        $j++;
        @endphp
        @endif

        @else
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p>{{$seats_silver[$i]->seat}}</p>
          <input type="checkbox" name="seat_id[]" value="{{$seats_silver[$i]->seat_id}}">
        </div>

        @endif

        @endfor
      </div>

      @else
      <!-- silver seat not booked any  -->
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Silver</h3>
        @foreach($seats_silver as $seats)
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p>{{$seats->seat}}</p>
          <input type="checkbox" name="seat_id[]" value="{{$seats->seat_id}}">
        </div>
        @endforeach
      </div>
      @endif


      <hr>

      <!-- gold seats  -->

      @if(!empty($booked_gold))
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Gold</h3>
        @php
        $j=0;
        @endphp

        @for($i=0; $i<count($seats_gold); $i++ )
        @if($seats_gold[$i]->seat_id == $booked_gold[$j]->seat_id)
        <div class="w3-quarter">
          <button class="button button2">|__|</button>
          <p>{{ $seats_gold[$i]->seat}}</p>

        </div>
        @if(count($booked_gold)-1 != $j)
        @php
        $j++;
        @endphp
        @endif

        @else
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p>{{$seats_gold[$i]->seat}}</p>
          <input type="checkbox" name="seat_id[]" value="{{$seats_gold[$i]->seat_id}}">
        </div>

        @endif

        @endfor
      </div>

      @else
      <!-- gold seat not booked any  -->
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Gold</h3>
        @foreach($seats_gold as $seats)
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p>{{$seats->seat}}</p>
          <input type="checkbox" name="seat_id[]" value="{{$seats->seat_id}}">
        </div>
        @endforeach
      </div>
      @endif


      <hr>


      <!-- Platinum seats  -->

      @if(!empty($booked_platinum))
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Platinum</h3>
        @php
        $j=0;
        @endphp

        @for($i=0; $i<count($seats_platinum); $i++ )
        @if($seats_platinum[$i]->seat_id == $booked_platinum[$j]->seat_id)
        <div class="w3-quarter">
          <button class="button button2">|__|</button>
          <p>{{ $seats_platinum[$i]->seat}}</p>
          <p>B</p>
        </div>
        @if(count($booked_platinum)-1 != $j)
        @php
        $j++;
        @endphp
        @endif

        @else
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p>{{$seats_platinum[$i]->seat}}</p>
          <input type="checkbox" name="seat_id[]" value="{{$seats_platinum[$i]->seat_id}}">
        </div>

        @endif

        @endfor
      </div>

      @else
      <!-- Platinum seat not booked any  -->
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <h3>Platinum</h3>
        @foreach($seats_platinum as $seats)
        <div class="w3-quarter">
          <button class="button">|__|</button>
          <p>{{$seats->seat}}</p>
          <input type="checkbox" name="seat_id[]" value="{{$seats->seat_id}}">
        </div>
        @endforeach
      </div>
      @endif

      <hr>
      <div class="w3-row-padding w3-padding-16 w3-center" id="food">
        <div class="w3-quarter">
          <button class="button button3" type="submit">BOOK</button>
        </div>
      </div>
      <h3 class="center">__\_____SCREEN______/__</h3>
      <!-- End page content -->
    </div>

  </form>

</body>
</html>
