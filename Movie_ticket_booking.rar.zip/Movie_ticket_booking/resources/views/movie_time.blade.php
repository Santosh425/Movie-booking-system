<!DOCTYPE html>
<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Karma", sans-serif}
.w3-bar-block .w3-bar-item {padding:20px}
</style>
<body>

    <!-- Sidebar (hidden by default) -->
    @include('sidebar')

    <!-- Top menu -->
    @include('topnav')

<!-- !PAGE CONTENT! -->
<div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:100px">

  <!-- First Photo Grid-->
  <div class="w3-row-padding w3-padding-16 w3-center" id="food">


      <div class="w3-quarter">
        @foreach($movie_timming as $movie)
        @endforeach
    <img src="{{url($movie->images)}}" alt="Sandwich" style="width:100%">
      <h3>{{$movie->movie_name}}</h3>
      <p>{{$movie->type}}</p>
    </div>
</div>


  <div class="w3-row-padding w3-padding-16 w3-center" id="food">
    <h3>show</h3>
    @foreach($movie_timming as $movie_time)
    <a href="{{route('movie_seats', ['movie_id'=>$movie_time->movie_id,'movie_time'=>$movie_time->m_time_id])}}">
      <div class="w3-quarter">
      <h3>{{ $movie_time->movie_time}}</h3>
      <p> {{$movie_time->movie_date}}</p>
    </div>
    </a>
    @endforeach
  </div>



<!-- End page content -->
</div>

<script>
// Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>

</body>
</html>
