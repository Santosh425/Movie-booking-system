<!DOCTYPE html>
<html>
<title>Seat Book</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">

@include('style')
<body>

  <!-- Sidebar (hidden by default) -->
  @include('sidebar')

  <!-- Top menu -->
  @include('topnav')

  <!-- !Page  CONTENT! -->


  <div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:100px">
    <!-- seat booked -->
  <?php
  if (!empty($booking )) {
    // code...

      foreach ($booking as $bookings) {
        // code...
        ?>
        <div class="w3-row-padding w3-padding-16 w3-center" id="food">
          <div class="w3-quarter">
            <input  class="w3-input" type="text"  value="{{$bookings->movie_name}}" readonly>
            <input  class="w3-input" type="text"  value="{{$bookings->type}}" readonly>
            <button class="button button2">|__|</button>
            <p>{{$bookings->seat}}</p>
            <input  class="w3-input" type="text"  value="{{$bookings->customer_id}}" readonly>
            <input  class="w3-input" type="text"  value="{{$bookings->seat_type}}" readonly>
            <input  class="w3-input" type="text"  value="Rs. {{$bookings->price}}" readonly>
            <input  class="w3-input" type="text"  value="{{$bookings->discount}}%" readonly>
            <a href="{{route('cancle_ticket',['b_id'=>$bookings->booking_id])}}">Cancle Seat (No Refund)</a>
          </div>
        </div>
<hr style=" border: 1px solid black;">
        <?php
      }
  }else {
    ?>
    <div class="w3-row-padding w3-padding-16 w3-center" id="food">
      <div class="w3-quarter">
        <button>|__|</button>
        <p>No Bookings</p>

      </div>
    </div>
    <?php
  }
?>


<!-- booking_amount-->
<?php
if (!empty($booking_amount)) {
  // code...

foreach ($booking_amount as $amount) {
  // code...
  ?>
  <div class="w3-row-padding w3-padding-16 w3-center" id="food">
    <div class="w3-quarter">
    <input  class="w3-input" type="text"  value="{{$amount->customer_id}}" readonly>
    <input  class="w3-input" type="text"  value="Sub Total- Rs.  {{$amount->amount}}" readonly>

    </div>
  </div>

  <?php
}
}
?>

</body>
</html>
