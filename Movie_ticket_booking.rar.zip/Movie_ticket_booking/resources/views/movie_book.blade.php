<!DOCTYPE html>
<html>
<title>Seat Book</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  @include('style')
<body>

  <!-- Sidebar (hidden by default) -->
  @include('sidebar')

  <!-- Top menu -->
  @include('topnav')

  <!-- !Page  CONTENT! -->


  <div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:100px">
    @foreach($movie as $mt)
    @endforeach
    <div class="w3-col-padding w3-padding-16 w3-center" id="food">
        <div class="w3-quarter">
        <img src="{{url($mt->images)}}" alt="Sandwich" style="width:90%">
        <h3>{{$mt->movie_name}}</h3>
        <p>{{$mt->type}}</p>
      </div>
    </div>

    <form  action="{{route('confirm_book',['movie_id'=>$mt->movie_id, 'movie_time'=>$mt->m_time_id])}}" method="get">
      <?php
      $j=0;
      $sum=0;
      foreach ($seats as $seat) {
        // code...
        for ($i=0; $i<count($seat) ; $i++) {
          // code...

          $price=  $seat[$i]->price;
          $type=  $seat[$i]->type;
          $seat_row=  $seat[$i]->seat;
          $seat_id =  $seat[$i]->seat_id;
          $sum += $seat[0]->price;
          ?>
          <div class="w3-row-padding w3-padding-16 w3-center" id="food">
            <div class="w3-quarter">

              <button  class="button">|__|</button>
              <p><?php echo "$seat_row"; ?></p>
              <input  class="w3-input" type="text"  value="<?php echo "$type" ?>" readonly>
              <input  class="w3-input"  type="text" name="seat_id[]" value="{{$seat_id }}"  readonly>
              <input  class="w3-input" type="text" name="price[]" value="<?php echo "$price" ?>" readonly>
              </div>
          </div>

          <?php

          if(count($seat)-1 != $j) {
            // code...
            $j++;
          }
        }





      }
      ?>
  <div class="w3-row-padding w3-padding-16 w3-center" id="food">
      <div class="w3-quarter">
        <select id="mySelect" name="coupon" onchange="myFunction()">
          <?php
          foreach ($coupons as $coupon) {
            // code...
            ?>
            <option value="{{$coupon->discount}}">{{$coupon->coupon}}-->{{$coupon->discount}}%</option>
            <?php
          }
          ?>
        </select>
        <input  class="w3-input" type="text" id="amount" name="total" value="{{$sum}}" readonly>
        <input  class="w3-input"  type="email" name="email" value="" required placeholder="Email Id">

        <button  class="button button3" type="submit">BOOK</button>
      </div>
    </div>
  </div>
  </form>


  <script>
  function myFunction() {
    var x = document.getElementById("mySelect").value;
    var y = document.getElementById("amount").value;
    var sum =y/100*x;
    var amount =y-sum;


    document.getElementById("amount").value = amount;

  }
</script>

</body>
</html>
