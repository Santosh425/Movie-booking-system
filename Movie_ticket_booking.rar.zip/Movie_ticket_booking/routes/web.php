<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Welcome;
use App\Http\Controllers\MovieSeat;
use App\Http\Controllers\MovieTime;
use App\Http\Controllers\Booking;
use App\Http\Controllers\MyBookings;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('welcome', [App\Http\Controllers\Welcome::class, 'display'])->name('welcome');
// select time
Route::get('movie_time/{movie_id}', [App\Http\Controllers\MovieTime::class, 'display'])->name('movie_time');
// select seat
Route::get('movie_seats/{movie_id}/{movie_time}', [App\Http\Controllers\MovieSeat::class, 'display'])->name('movie_seats');
// book seat
Route::get('book_seat/{movie_id}/{movie_time}', [App\Http\Controllers\Booking::class, 'bookseat'])->name('book_seat');
// final amount
Route::get('confirm_book/{movie_id}/{movie_time}', [App\Http\Controllers\Booking::class, 'final_booking'])->name('confirm_book');
//view bookings
Route::get('bookings', [App\Http\Controllers\MyBookings::class, 'display'])->name('bookings');

Route::get('cancle_ticket/{b_id}', [App\Http\Controllers\MyBookings::class, 'cancle_ticket'])->name('cancle_ticket');
