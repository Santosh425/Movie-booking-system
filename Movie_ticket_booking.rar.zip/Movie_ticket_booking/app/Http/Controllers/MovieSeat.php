<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class MovieSeat extends Controller
{
    //

  public function display($movie_id,$movie_time)
  {
    // code...
    $movie= DB::select('select * from movies as m , movie_time as mt
   WHERE m.movie_id = mt.movie_id AND
    mt.movie_id = "'.$movie_id.'" AND
    mt.m_time_id = "'.$movie_time.'" ');

 $seats_silver=  DB::select('select * FROM seats where type = "silver" ');
 $booked_silver= DB::select('select * from movies as m , seats as s, movie_time as mt, booking as b
 where m.movie_id = b.movie_id AND
 s.seat_id = b.seat_id AND
 mt.m_time_id = b.m_time_id AND
 b.movie_id = "'.$movie_id.'" AND
 b.m_time_id = "'.$movie_time.'"  AND
 s.type="silver"
 ORDER BY s.seat_id ASC ');

 $seats_gold=  DB::select('select * FROM seats where type = "gold" ');
 $booked_gold= DB::select('select * from movies as m , seats as s, movie_time as mt, booking as b
 where m.movie_id = b.movie_id AND
 s.seat_id = b.seat_id AND
 mt.m_time_id = b.m_time_id AND
 b.movie_id = "'.$movie_id.'" AND
 b.m_time_id = "'.$movie_time.'"  AND
 s.type="gold"
 ORDER BY s.seat_id ASC ');

 $seats_platinum=  DB::select('select * FROM seats where type = "Platinum" ');
 $booked_platinum= DB::select('select * from movies as m , seats as s, movie_time as mt, booking as b
 where m.movie_id = b.movie_id AND
 s.seat_id = b.seat_id AND
 mt.m_time_id = b.m_time_id AND
 b.movie_id = "'.$movie_id.'" AND
 b.m_time_id = "'.$movie_time.'"  AND
 s.type="Platinum"
 ORDER BY s.seat_id ASC ');

return View('movie_seat')->with('movie',$movie)->with('seats_silver',$seats_silver)->with('seats_gold',$seats_gold)->with('seats_platinum',$seats_platinum)->with('booked_silver',$booked_silver)->with('booked_gold',$booked_gold)->with('booked_platinum',$booked_platinum);

  }
}
