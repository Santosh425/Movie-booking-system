<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class MyBookings extends Controller
{
  //
  public function display()
  {

    $booking = DB::select('select  *, s.type as seat_type FROM booking as b , seats as s, movies as m, movie_time as mt
    WHERE b.seat_id = s.seat_id AND
    b.movie_id = m.movie_id AND
    b.m_time_id = mt.m_time_id;');

    $booking_amount = DB::select('select *,sum(total_amount) as amount FROM booking GROUP by (customer_id)');



    return View('mybookings')->with('booking',$booking)->with('booking_amount',$booking_amount);
  }

  public function cancle_ticket($b_id)
  {
    // code...
     DB::delete('delete FROM booking WHERE booking_id ="'.$b_id.'" ');
     return $this->display();
  }
}
