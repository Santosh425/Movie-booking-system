<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class Welcome extends Controller
{
    //
    public function display()
    {
      // code...
      $movies = DB::select('select * FROM movies');
      return View('welcome')->with('movies',$movies);
    }

}
