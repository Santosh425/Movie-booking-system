<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class MovieTime extends Controller
{
    //
    public function display($movie_id)
    {
      $movie_timming = DB::select('select * FROM movie_time as  mt, movies as m
      WHERE mt.movie_id = m.movie_id and
      mt.movie_id ="'.$movie_id.'"');

      return View('movie_time')->with('movie_timming',$movie_timming);
    }
}
