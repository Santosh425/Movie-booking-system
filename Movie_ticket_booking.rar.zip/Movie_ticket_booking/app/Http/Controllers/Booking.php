<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class Booking extends Controller
{
  //
  // show seat and amount details
  public function bookseat(Request $req, $movie_id,$movie_time)
  {
    // code...
    $movie= DB::select('select * from movies as m , movie_time as mt
   WHERE m.movie_id = mt.movie_id AND
    mt.movie_id = "'.$movie_id.'" AND
    mt.m_time_id = "'.$movie_time.'" ');

    $coupons= DB::select('select * FROM coupons');

    $seat_id=  $req->input('seat_id');
    foreach ($seat_id as $id ) {
      // code...
      $seats[]=  DB::select('select * FROM seats where seat_id ="'.$id.'"  ');

    }


  return View('movie_book')->with('seats',$seats)->with('movie',$movie)->with('coupons',$coupons);

  }

// book ticket
public function final_booking(Request $req,$movie_id,$movie_time)
{
  // code...
      $seat_id=  $req->input('seat_id');
      $email =$req->input('email');
      $coupon =$req->input('coupon');
      $total = $req->input('total');

      foreach ($seat_id as $id) {

          DB::insert('insert INTO booking(customer_id, seat_id, movie_id, m_time_id,discount,	total_amount)
          values(?,?,?,?,?,?)',[$email,$id,$movie_id,$movie_time,$coupon,$total]);
      }

      // DB::insert('insert INTO booking_amount(customer_id,movie_id, m_time_id,discount,total_amount)
      // values(?,?,?,?,?)',[$email,$movie_id,$movie_time,$coupon,$total]);

return redirect()->route('bookings');


}

}
